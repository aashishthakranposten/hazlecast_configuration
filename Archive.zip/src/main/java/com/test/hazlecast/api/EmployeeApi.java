package com.test.hazlecast.api;

import com.test.hazlecast.model.Employee;
import com.test.hazlecast.service.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeApi {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public ResponseEntity create(@RequestBody Employee employee) {
        Employee e = employeeService.insertEmployee(employee);
        return ResponseEntity.ok(e);
    }

    @GetMapping(value = "/{empId}")
    public ResponseEntity getEmployee(@PathVariable String empId) {
        Employee employee = employeeService.getEmployeeById(empId);
        return ResponseEntity.ok(employee);
    }
}
