package com.test.hazlecast.service;

import com.test.hazlecast.model.Employee;

public interface EmployeeService {
	Employee insertEmployee(Employee emp);
	Employee getEmployeeById(String empid);
}
