package com.test.hazlecast.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.test.hazlecast.model.Employee;
import com.test.hazlecast.service.EmployeeService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private static Map<String, Employee> STORE = new HashMap<>();

	@Override
	public Employee insertEmployee(Employee employee) {
		STORE.put(employee.getEmpId(), employee);
		return employee;
	}

	@Override
	@Cacheable(key="#empId", cacheNames = "employees")
	public Employee getEmployeeById(String empId) {
		return STORE.get(empId);
	}
}
